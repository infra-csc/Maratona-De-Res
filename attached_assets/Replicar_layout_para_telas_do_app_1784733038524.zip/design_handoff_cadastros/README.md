# Handoff: Telas de Cadastros — Novo Visual "Premium"

## Overview
Restyle das 5 telas de Cadastros do app (Colaboradores, Critérios, Áreas, Usuários, Tipos de Lançamento) para o novo sistema visual "premium" já em uso na tela de avaliação pública (/eval/:token) e sendo propagado tela por tela pelo app interno. Mantém toda a estrutura de dados e ações das telas originais, trocando o antigo visual "brutalista" (Plus Jakarta Sans, bordas retas 2px, itálico, sombras duras) pelo novo visual (Barlow / Barlow Condensed, cantos arredondados, tokens de tema claro/escuro, acento lima/oliva).

## About the Design Files
Os arquivos `.dc.html` neste pacote são **referências de design em HTML** — protótipos estáticos com dados de exemplo (mock), mostrando o visual e comportamento pretendidos. Eles não são código de produção para copiar diretamente. A tarefa é **recriar este visual no código real do app** (React + Tailwind + Vite, stack já usada no projeto `Maratona-De-Res`), reaproveitando os componentes, hooks e chamadas de API já existentes em cada página (`employees.tsx`, `criteria.tsx`, `areas.tsx`, `users.tsx`, `penalty-types.tsx`) — só a camada visual muda.

## Fidelity
**Alta fidelidade (hifi)** quanto a paleta, tipografia, espaçamento e estrutura de layout — cores exatas, escala de fonte e tokens estão especificados abaixo. Os dados exibidos nos protótipos são **mock** (nomes, contagens); a integração real deve usar os hooks de API já existentes em cada página original.

## Design Tokens

Copiar exatamente o sistema já usado em `src/lib/premium-theme.tsx` (fonte da verdade — reaproveitar, não recriar):

```
CONDENSED = "'Barlow Condensed', sans-serif"   // headings, labels, badges, botões
BODY      = "'Barlow', sans-serif"              // texto corrido
WARNING   = "#e5484d"                           // erro/inelegível/excluir (fixo, não varia por tema)

darkTokens = {
  background: "#0c0c0c", foreground: "#f0ede8",
  card: "#141414", primary: "#d4ff00", primaryForeground: "#0c0c0c",
  secondary: "#1e1e1e", mutedForeground: "#7a7a7a",
  accent: "#d4ff00", border: "rgba(255,255,255,0.08)",
}
lightTokens = {
  background: "#f2f1ec", foreground: "#111111",
  card: "#ffffff", primary: "#111111", primaryForeground: "#ffffff",
  secondary: "#e8e6e0", mutedForeground: "#888880",
  accent: "#9ab000", border: "rgba(0,0,0,0.1)",
}
```

Escala usada nos protótipos:
- Border radius: 8–12px em cards e botões, 999px (pill) em badges de status.
- Cards: `border: 1px solid var(--border)`, sem sombra dura (o antigo `shadow-[4px_4px_0px_0px_#191c1e]` foi removido).
- Título de página: Barlow Condensed 900, 24px, uppercase.
- Labels/eyebrow: Barlow Condensed 700, 10–11px, uppercase, letter-spacing .08–.15em, cor `mutedForeground`.
- Corpo/texto de linha: Barlow 400–700, 12–13px.

## Screens / Views

Todas as 5 telas compartilham o mesmo shell:
- **Sidebar** (250px fixa): logo "Maratona / Resultados", grupos de navegação (Gestão / Cadastros / Controle / Colaborador) com o item ativo destacado em `primary`, toggle Dark/Light, cartão do usuário logado, botão Encerrar Sessão.
- **Header da página**: título (Barlow Condensed 24px) + subtítulo descritivo + botão de tema + botão de ação primária (`+ Novo …`) em `primary`.
- **Área de conteúdo**: `flex:1; overflow:auto`, padding 20/24px.

### 1. Colaboradores
- **Propósito**: gestão do time e elegibilidade para bônus da Maratona.
- **KPIs** (3 cards): Total de Registros, Ativos, Elegíveis para Bônus — cada um com barra de progresso proporcional ao total.
- **Filtros**: busca por nome/função/departamento; toggle Ativos/Inativos; toggle Todos os Tipos/Casa/Freela.
- **Lista**: linha por colaborador — avatar (iniciais), nome + e-mail, departamento, cargo, badge de tipo (Casa/Freela), badge de status (Ativo/Inativo), rótulo de elegibilidade (Elegível / Não Elegível / Freela — não pontua / — Sem dados), botão Editar.

### 2. Critérios
- **Propósito**: gerenciar os critérios usados para avaliar eventos.
- **Filtros**: chips por área (Todos + uma por área existente); busca por nome.
- **Tabela**: Critério, Área, Peso, Status (Ativo/Inativo), Ações (editar/excluir).

### 3. Áreas
- **Propósito**: gerenciar departamentos/áreas organizacionais e relacionar critérios/usuários a cada uma.
- **Filtros**: Todos/Ativos/Inativos; busca.
- **Grid de cards** (3 colunas): ícone, badge de status, nome da área, descrição, contagem de Critérios e Usuários (chips), botão Gerenciar (abre relação critérios/usuários — não prototipado em detalhe, manter o dialog com abas Critérios/Usuários da tela original).

### 4. Usuários
- **Propósito**: controlar quem acessa a plataforma e seu nível de permissão.
- **KPIs** (3 cards): Total de Usuários, Ativos Agora, Nível Admin.
- **Busca**: por nome, CPF ou e-mail.
- **Lista**: avatar, nome + e-mail, badge de perfil (Admin/RH/Avaliador/Diretoria/Visualizador — cores por papel), área, badge de status, ações (editar, redefinir senha, remover — ícones).

### 5. Tipos de Lançamento
- **Propósito**: configurar tipos de penalidade e mérito e seus valores em pontos.
- **Ações do header**: Restaurar Padrões, + Novo Tipo.
- **Duas colunas**: Penalidades (−, acento vermelho `#e5484d`) e Méritos (+, acento `accent`) — cada uma lista linhas com nome, slug (monospace), tag "requer evento" quando aplicável, valor em pontos, ações (editar/excluir).
- **Rodapé**: caixa informativa (fundo `accent` translúcido) explicando o funcionamento dos tipos.

## Interactions & Behavior
- Toggle Dark/Light: troca todos os tokens de cor da página (persistir em localStorage como no restante do app, chave própria por página ou reaproveitando a global do `PremiumThemeProvider`).
- Filtros e busca são client-side sobre a lista já carregada (mesma lógica das páginas originais — apenas a camada visual muda).
- Botões de ação (Novo Colaborador, Novo Critério, etc.) devem reabrir os **dialogs/forms já existentes** nas páginas originais (não foram redesenhados neste pacote — manter estrutura de campos, apenas restilizar com os tokens acima se desejado).

## Assets
Nenhum asset externo — apenas Google Fonts (Barlow, Barlow Condensed) já carregadas via `<link>` no `index.css` do projeto.

## Files
- `Colaboradores.dc.html`
- `Criterios.dc.html`
- `Areas.dc.html`
- `Usuarios.dc.html`
- `Tipos de Lancamento.dc.html`

Cada arquivo é standalone e abre direto no navegador. Fonte de dados real a integrar por tela: `employees.tsx`, `criteria.tsx`, `areas.tsx`, `users.tsx`, `penalty-types.tsx` (mesmo repositório, branch `main`).
