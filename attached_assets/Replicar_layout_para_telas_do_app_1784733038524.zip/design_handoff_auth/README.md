# Handoff: Telas de Login / Troca de Senha — Novo Visual "Premium"

## Overview
Restyle das telas de autenticação (`login.tsx`, `change-password.tsx`) para o novo sistema visual "premium" já propagado no restante do app (mesmo tema usado em Cadastros, Eventos, Avaliações, Calibrações, Dashboard etc). Mantém toda a lógica de autenticação existente — apenas a camada visual muda.

## About the Design Files
Os arquivos `.dc.html` são referências de design em HTML — protótipos estáticos, não código de produção. Recriar o visual no código real (React + Tailwind + Vite), reaproveitando os hooks `useLogin` / `useChangePassword`, `useAuth`, `useToast` já existentes — só a camada visual muda.

## Fidelity
Alta fidelidade quanto a paleta, tipografia, espaçamento e estrutura. Tokens abaixo (mesmos de `src/lib/premium-theme.tsx`, fonte da verdade):

```
CONDENSED = "'Barlow Condensed', sans-serif"
BODY      = "'Barlow', sans-serif"
WARNING   = "#e5484d"

darkTokens = { background:"#0c0c0c", foreground:"#f0ede8", card:"#141414", primary:"#d4ff00", primaryForeground:"#0c0c0c", secondary:"#1e1e1e", mutedForeground:"#7a7a7a", accent:"#d4ff00", border:"rgba(255,255,255,0.08)" }
lightTokens = { background:"#f2f1ec", foreground:"#111111", card:"#ffffff", primary:"#111111", primaryForeground:"#ffffff", secondary:"#e8e6e0", mutedForeground:"#888880", accent:"#9ab000", border:"rgba(0,0,0,0.1)" }
```

Cards com `border-radius: 14px`, `border: 1px solid var(--border)`, sem sombra dura. Inputs 46px altura, `border-radius: 9px`, fundo `secondary`. Botão primário `border-radius: 10px`, fundo/borda `primary`, texto `primaryForeground`, Barlow Condensed 800, uppercase.

## Screens

### 1. Login (`login.tsx`)
- Tela centralizada, largura máx. 400px, fundo `background`.
- Logo: quadrado 56px `radius:14px` cor `primary` com ícone; título "Maratona de / Resultados" (Barlow Condensed 900, 26px, segunda linha em `accent`).
- Card: header "Acesso Corporativo / Cenográfica Eventos"; form com campos CPF/E-mail e Senha; botão "Acessar Plataforma →" full width.
- Rodapé: "Sistema Exclusivo · Uso Restrito" (uppercase, 10px, letter-spacing largo).
- Manter toda a lógica: `useLogin`, toast de erro "Acesso Negado", redirect para `/trocar-senha` se `mustChangePassword`.

### 2. Troca de Senha (`change-password.tsx`)
- Mesmo shell da tela de login.
- Título "Primeiro Acesso / Troque sua Senha".
- Card: header "Olá, {nome do usuário}"; campos Nova Senha e Confirmar Nova Senha; validação inline (mensagem "As senhas não coincidem" quando divergem, antes do submit); botão "Confirmar Nova Senha →".
- Manter lógica: `useChangePassword`, toast de erro/sucesso, redirect condicional por `role`.

## Interactions
- Toggle Dark/Light no canto superior direito (reaproveitar `PremiumThemeProvider` global, mesma chave usada nas outras telas).
- Sem novos comportamentos — validações e submits são os já existentes nas páginas originais.

## Assets
Google Fonts (Barlow, Barlow Condensed) já carregadas no projeto.

## Files
- `Login.dc.html`
- `Trocar Senha.dc.html`

Fonte de dados/lógica real: `login.tsx`, `change-password.tsx` (mesmo repositório, branch `main`).
